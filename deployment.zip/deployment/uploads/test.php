<?php echo 'Upload directory is writable'; ?>
